/*
*********************************************************************************************************
*                                                uC/OS-II
*                                          The Real-Time Kernel
*
*                              (c) Copyright 2002, Micrium, Inc., Weston, FL
*                                           All Rights Reserved
*
*                                           MASTER INCLUDE FILE
*********************************************************************************************************
*/

#ifndef INCLUDES_H
#define INCLUDES_H

#include    <stdio.h>
#include    <string.h>
#include    <ctype.h>
#include    <stdlib.h>
//#include    <in430.h>
//#include    <msp430x14x.h>
#include    <os_cpu.h>
#include    "os_cfg.h"
#include    <ucos_ii.h>
#include    <io.h>
#include    <iomacros.h>

#include	"radio_cfg.h"

#endif
