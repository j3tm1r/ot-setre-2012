PATH=/usr/local/msp430-pytools/bin:$PATH
PATH=/usr/local/msp430-gcc-4.4.4/bin:$PATH

LD_LIBRARY_PATH=/usr/local/msp430-pytools/lib:$LD_LIBRARY_PATH

export PATH
export LD_LIBRARY_PATH
