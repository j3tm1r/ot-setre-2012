chmod a+x conf.sh
source conf.sh
msp430-insight
